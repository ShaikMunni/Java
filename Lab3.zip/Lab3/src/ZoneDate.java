import java.time.ZoneId;
import java.time.ZonedDateTime;

public class ZoneDate {

	ZoneDate(){}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/* ZonedDateTime currentTime = ZonedDateTime.now();
         ZonedDateTime currentTimeInParis = ZonedDateTime.now(ZoneId.of("Europe/Paris"));
         ZonedDateTime current=ZonedDateTime.now(ZoneId.of("America/New_York"));
         ZonedDateTime currentTimeInNewYork1 = currentTime.withZoneSameInstant(ZoneId.of("America/New_York"));
         ZonedDateTime currentTimeInNewYork = currentTime.withZoneSameLocal(ZoneId.of("America/New_York"));
         System.out.println("India:"+ currentTime);
         System.out.println("Paris:"+ currentTimeInParis);
         System.out.println("New York:"+ currentTimeInNewYork);
         System.out.println("New York:"+ currentTimeInNewYork1);
         System.out.println("New York:"+ current);*/
		String s=new String("aaaa");
		String s1=new String("aaaa");
		System.out.println(s==s1);
		ZoneDate z=new ZoneDate();
	ZoneDate z1=new ZoneDate();
	System.out.println(z==z1);
		
		
	}

}
