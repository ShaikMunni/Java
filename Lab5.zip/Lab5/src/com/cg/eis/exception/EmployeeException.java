package com.cg.eis.exception;
import  com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;
public class EmployeeException{{

	

	
	try
	{
		if(Employee.salary<3000)
		{
			throw new balCheck();
		}
	}
	catch(Exception e)
	{
		balCheck b=new balCheck();
		 String s=b.check();
		 System.out.println(s);
	}
	
}
public class balCheck extends Exception
{
	public String check()
	{
		return("Balance is less than 3000");
	}
}}



