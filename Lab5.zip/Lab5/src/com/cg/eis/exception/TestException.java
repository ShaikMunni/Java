package com.cg.eis.exception;

import com.cg.eis.exception.EmployeeException;
import com.cg.eis.exception.EmployeeException.balCheck;
import static org.junit.Assert.assertEquals;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.eis.exception.EmployeeException.balCheck;
public class TestException {
	EmployeeException x=new EmployeeException();
	balCheck b1=x.new balCheck();
	@Test(expected=balCheck.class)
	
	public void CheckException()
	{
		String result="com.cg.eis.exception.EmployeeException$balCheck";
		assertEquals(b1,result);
	}

}
