package com.cg.eis.bean;

public class Employee 
{
	public static  int id;
	public static  String name;
	public static String designation;
	public static String insurance;
	public static double salary;
	public Employee(int i,String n,String d,double s)
	{
		id=i;
		name=n;
		designation=d;
		
		salary=s;
	}
}
