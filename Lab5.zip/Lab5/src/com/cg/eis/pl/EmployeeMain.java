
package com.cg.eis.pl;
import java.util.Scanner;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.exception.EmployeeException.balCheck;
import  com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;
public class EmployeeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id of the employee:");
		int id=sc.nextInt();
		System.out.println("Enter name of the employee:");
		String name=sc.next();
		//System.out.println("Enter designation of the employee:\n System Associate \nProgrammer \n Manager \n Clerk");
		//String des=sc.next();
		System.out.println("Enter salary of the employee:");
		long sal=sc.nextLong();
		Employee e=new Employee(id,name,"Programmer",sal);
		String n=e.designation;
		double d=e.salary;
		
		Service s=new Service();
		s.insuranceScheme(d,n);
		s.display();
		EmployeeException b=new EmployeeException();
		balCheck b1=b.new balCheck();
		System.out.println(b1);
		
		
		
		
		
		
		
		
		
	}
}