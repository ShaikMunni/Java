interface asus
{
	void camera();
}
class asusZen2 implements asus
{

	@Override
	public void camera() {
		// TODO Auto-generated method stub
		System.out.println("Asus mobile..........");
	}
	
}
public class Annotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		asusZen2 a=new asusZen2();
		a.camera();
	}

}
