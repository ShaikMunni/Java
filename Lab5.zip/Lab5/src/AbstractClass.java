abstract class Account {

long accNum;

double balance=500;

String accHolder;

 

void setDeposit(double d){

balance+=d;

 

}

abstract void getWithdraw(double w);

double getBalance()
{
	return balance;
}

/*void display()
{
	System.out.println(accNum+" "+balance+" "+accHolder);
}*/
public String toString()
{//overriding the toString() method  
	  return accNum+" "+balance+" "+accHolder;  
}
 }
class AbstractClass extends Account
{
	String name;
	float age;
	AbstractClass(long aNo,  String aHo, float ag)

	{

	accNum=aNo;



	accHolder=aHo;

	age=ag;

	}
	
	void getWithdraw(double w)
	{

		if(balance>=500){

		balance-=w;

		}

		else System.out.println("Insufficient balance.");




		}
	public static void main(String[] args) 
	{

		// TODO Auto-generated method stub

		AbstractClass a=new AbstractClass(100001L,"Smith",45);

		AbstractClass b=new AbstractClass(100002L,"Kethy",40);
		a.setDeposit(2000);
		b.setDeposit(3000);
		

		a.getBalance();

		b.getBalance();
		a.getWithdraw(200);
		 a.getBalance();

		System.out.println("\nUpdated BalanceSheet\n--------------------");
		
		//a.display();

		//b.display();
		System.out.println(a.toString());
		System.out.println(b.toString());
	}

	


}
	
 


