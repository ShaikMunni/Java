package com.cg.products.dao;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ProductDao {
	Connection con=null;
	PreparedStatement ps=null;
	
	public Connection getConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			con=DriverManager.getConnection(url,user,pass);
			return con;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
	public boolean  validate(String name,String password)
	{
		/*response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("user");
		String password=request.getParameter("pass");
	
		if(username.equals("munni") && password.equals("123"))
		{
			//RequestDispatcher rd=request.getRequestDispatcher("https://www.google.com");
			//rd.forward(request, response);
			response.sendRedirect("home.jsp");
		}
		else
		{
			out.println("<b style='color:red'>User is invalid.</b>");
			RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.forward(request, response);
			
		}*/
		con=getConnection();
		
		String sql="select * from user_details where password=?";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1, password);
			ResultSet n=ps.executeQuery();
			boolean res=n.next();
			return res;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
		
	}
	
	public int addProduct(String id,String username,String price,String model)
	{
		con=getConnection();
		String sql="insert into products values(?,?,?,?)";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1, id);
			ps.setString(2,username);
			ps.setString(3,price);
			ps.setString(4,model);
			//ps.setString(4,mobile);
			int n=ps.executeUpdate();
			return n;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	public int add(String username,String password,String mail,String mobile)
	{
		con=getConnection();
		String sql="insert into user_details values(?,?,?,?)";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1,username);
			ps.setString(2,password);
			ps.setString(3,mail);
			ps.setString(4,mobile);
			int n = ps.executeUpdate();
			return n;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	public int edit(String id,String p)
	{
		con=getConnection();
		String sql="update products set price=? where id=?";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(2,id);
			ps.setString(1,p);
		
			int n=ps.executeUpdate();
			return n;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	public int delete(String id)
	{
		con=getConnection();
		String sql="delete from products where id=?";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1,id);
			
		
			int n=ps.executeUpdate();
			return n;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
	}
	public boolean  val(String mobile,String username)
	{
		
		con=getConnection();
		
		String sql="select * from user_details where mobile=?";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1, mobile);
			ResultSet n=ps.executeQuery();
			boolean res=n.next();
			//if(n.getString(1).equals(username))
			return res;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
		
	}
	
	public int  forgot1(String mobile,String pass)
	{
		System.out.println("sdhyugfyusgus");
		con=getConnection();
		
		String sql="update user_details set password=? where mobile=?";
		System.out.println("1");
		try{
			System.out.println("2");
			ps=con.prepareStatement(sql);
			System.out.println("3");
			ps.setString(1,pass);
			System.out.println("4");
			ps.setString(2,mobile);
			System.out.println("5");
			int n = ps.executeUpdate();
			System.out.println(n+"ugtfytvfty");
			return n;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}

}
