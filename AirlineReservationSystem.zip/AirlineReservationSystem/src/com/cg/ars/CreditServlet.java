package com.cg.ars;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ars.dao.ARSDao;

/**
 * Servlet implementation class CreditServlet
 */
@WebServlet("/CreditServlet")
public class CreditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String credit =request.getParameter("card");
		String mail =request.getParameter("mail");
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		ARSDao dao=new ARSDao();
		int b=dao.creditInfo(mail,credit);
		System.out.println(b);
		if(b>0)
		{
			response.sendRedirect("ticket.jsp");
		}
	}

}
