package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ARSDao {
	Connection con=null;
	PreparedStatement ps=null;
	
	public Connection getConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			con=DriverManager.getConnection(url,user,pass);
			return con;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
	/*public String role(String r) throws SQLException
	{
		con=getConnection();
		String sql="select * from users where username=?";
		ps.setString(1, r);
		ResultSet n=ps.executeQuery();
		String s=n.getString(3);
		System.out.println(s);
		return s;
		
		
	}*/
	public String  val(String name,String password)
	{
		con=getConnection();
		String sql="select * from users where password=?";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1, password);
			ResultSet n=ps.executeQuery();
			/*boolean res=n.next();
			System.out.println(res);
			return res;*/
			while(n.next())
			{
			String s=n.getString(3);
			System.out.println(s);
			return s;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
		
	}
}
