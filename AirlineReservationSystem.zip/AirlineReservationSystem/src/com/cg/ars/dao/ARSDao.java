package com.cg.ars.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ARSDao {
	Connection con=null;
	PreparedStatement ps=null;
	PreparedStatement ps1=null;
	public Connection getConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			con=DriverManager.getConnection(url,user,pass);
			return con;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return con;
	}
	/*public String role(String r) throws SQLException
	{
		con=getConnection();
		String sql="select * from users where username=?";
		ps.setString(1, r);
		ResultSet n=ps.executeQuery();
		String s=n.getString(3);
		System.out.println(s);
		return s;
		
		
	}*/
	public String  val(String name,String password)
	{
		con=getConnection();
		String sql="select * from users where password=?";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1, password);
			ResultSet n=ps.executeQuery();
			/*boolean res=n.next();
			System.out.println(res);
			return res;*/
			while(n.next())
			{
			String s=n.getString(3);
			System.out.println(s);
			return s;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
		
	}
	public int add(String username,String password,String role,String mobile)
	{
		con=getConnection();
		String sql="insert into users values(?,?,?,?)";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1,username);
			ps.setString(2,password);
			ps.setString(3,role);
			ps.setString(4,mobile);
			int n=ps.executeUpdate();
			return n;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	public int  booking(int number,String classtype,String srccity,String destcity)
	{
		con=getConnection();
		String sql="insert into booking_info(Booking_id,no_of_passengers,class_type,seat_numbers,src_city,dest_city) values(id_seq.nextVal,?,?,seatnumber_seq.nextval,?,?)";
		
			try{
				ps=con.prepareStatement(sql);
				System.out.println(1);
				ps.setInt(1, number);
				ps.setString(2,classtype);
				//ps.setString(4,1000);
				ps.setString(3,srccity);
				ps.setString(4,destcity);
				int n=ps.executeUpdate();
			return n;
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return 0;
	}
	public int creditInfo(String mail,String card)
	{
		con=getConnection();
		String s="select max(Booking_id) from booking_info";
		String sql="update booking_info set cust_email=?,CreditCard_info=? where Booking_id=?";
		String id=null;
		try{
			ps=con.prepareStatement(sql);
			ps1=con.prepareStatement(s);
			ResultSet res=ps1.executeQuery();
			if(res.next())
			{
			id=res.getString(1);
			}
			ps.setString(1, mail);
			ps.setString(2,card);
			ps.setString(3, id);
			int n=ps.executeUpdate();
			System.out.println(3);
			return n;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
	public int addProduct(String flightno,String airlines,String depcity1,String arrcity1,String depdate1,String ardate1,String dtime1,String atime1,String firstseat1,String firstseatfare1,String busseat1,String busfare1)
	{
		con=getConnection();
		String sql="insert into FlightInformation values(s_seq.nextval,?,?,?,?,?,?,?,?,?,?,?,?)";
		try{
			ps=con.prepareStatement(sql);
			ps.setString(1,flightno);
			ps.setString(2,airlines);
			ps.setString(3,depcity1);
			ps.setString(4,arrcity1);
			ps.setString(5,depdate1 );
			ps.setString(6, ardate1 );
			ps.setString(7, dtime1);
			ps.setString(8,atime1);
			ps.setString(9,firstseat1);
			ps.setString(10,firstseatfare1);
			ps.setString(11,busseat1);
			ps.setString(12, busfare1);

			int n=ps.executeUpdate();
			System.out.println(n);
			return n;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return 0;
		
	}
}

