package com.cg.ars;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ars.dao.ARSDao;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("usern");
		String password=request.getParameter("passs");
		//String role=request.getParameter("role");
		
		ARSDao dao=new ARSDao();
		
		String b=dao.val(username,password);
		System.out.println(b);
		
			if(b.equals("user"))
			{
			response.sendRedirect("reserve1.jsp");
			}
			else if(b.equals("admin"))
			{
				response.sendRedirect("admin.jsp");
			}
			else if(b.equals("exec"))
			{
				response.sendRedirect("exec.jsp");
			}
			else
			{
				out.println("<b style='color:red'>User is invalid</b>");
				RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
			}
		
	
	//	int n=dao.add(username, password, mail, mobile)
	
	}
}


