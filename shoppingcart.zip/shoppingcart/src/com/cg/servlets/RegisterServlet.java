package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlets.dao.UserDao;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("user");
		String password=request.getParameter("pass");
		String email=request.getParameter("mail");
		String phonenumber=request.getParameter("mobile");
		
		
		
		/*out.println("<html>");
		out.println("<body");
		out.println("<p>Welcome Miss. "+username+"</p>");
		out.println("<p> You entered password : "+password+"</p>");
		out.println("<p>Your mail id :"+email+"</p>");
		out.println("<p>Your mobile number :"+phonenumber+"</p>");
		
		out.println("</body></html>");*/
	/*	out.println("<b style='color:green'>Registered successfully</b>");
		RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
		rd.include(request, response);*/
		
		
		UserDao dao=new UserDao();
	/*	ServletContext sc=getServletContext();
		try{
			Class.forName(sc.getInitParameter("driver_class"));
			String url=sc.getInitParameter("url");
			String user=sc.getInitParameter("user");
			String pass=sc.getInitParameter("password");
			Connection con=DriverManager.getConnection(url,user,pass);
			System.out.println("db connected");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}*/
		int n=dao.add(username, password, email, phonenumber);
		//int n=0;
		if(n>0)
		{
			response.sendRedirect("login.jsp");
			/*RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
			rd.include(request, response);*/
			
		}
		else
		{
			/*RequestDispatcher rd=request.getRequestDispatcher("register.jsp?emsg=something went wrong,register again");
			rd.include(request, response);*/
			response.sendRedirect("register.jsp?emsg=something went wrong,register again");
		}
		
	}

}
